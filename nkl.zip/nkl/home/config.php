<?php

$METRI_TOKEN = "https://api.telegram.org/bot6398704693:AAEVpYZ3nn4dW9Q3TWJggJCtYJ-NBCDal4k";

$chat_id = "-946713109";

// $reload = '3';

?>